# Messed Up Game — Fresh Build

A live online party game stack with Supabase, Netlify Functions, reminders, and a lobby.

## Environment Variables (Netlify → Site settings → Environment)
```
VITE_SUPABASE_URL=YOUR_SUPABASE_URL
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY

SUPABASE_URL=YOUR_SUPABASE_URL
SUPABASE_SERVICE_ROLE=YOUR_SERVICE_ROLE_KEY
RESEND_API_KEY=YOUR_RESEND_API_KEY
FROM_EMAIL=host@gotbackuptomb.com
SITE_URL=https://play.messedupgame.com
VITE_STRIPE_PAYMENT_LINK_TICKET=https://buy.stripe.com/your_ticket
VITE_STRIPE_PAYMENT_LINK_TIP=https://buy.stripe.com/your_tip
```

## SQL — Core Tables & Policies

### events
```sql
create extension if not exists "pgcrypto";

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  starts_at timestamptz,  -- null for recurring
  room text not null,
  is_public boolean not null default true,
  recurrence text check (recurrence in ('none','daily','weekly')) default 'none',
  timezone text default 'America/Los_Angeles',
  weekday int check (weekday between 0 and 6),
  time_of_day text, -- 'HH:MM'
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.events enable row level security;

drop policy if exists "Public can read public events" on public.events;
create policy "Public can read public events"
on public.events for select to anon using (is_public = true);

drop policy if exists "Users can read all events" on public.events;
create policy "Users can read all events"
on public.events for select to authenticated using (true);
```

### admin_emails + admin-only writes
```sql
create table if not exists public.admin_emails ( email text primary key );
alter table public.admin_emails enable row level security;

drop policy if exists "Auth can view admin list" on public.admin_emails;
create policy "Auth can view admin list"
on public.admin_emails for select to authenticated using (true);

insert into public.admin_emails(email) values ('tom@gotbackuptomb.com')
on conflict (email) do nothing;

drop policy if exists "Admins can insert events" on public.events;
drop policy if exists "Admins can update events" on public.events;
drop policy if exists "Admins can delete events" on public.events;

create policy "Admins can insert events"
on public.events for insert to authenticated
with check (exists (select 1 from public.admin_emails a where a.email = (auth.jwt() ->> 'email')));

create policy "Admins can update events"
on public.events for update to authenticated
using (exists (select 1 from public.admin_emails a where a.email = (auth.jwt() ->> 'email')))
with check (exists (select 1 from public.admin_emails a where a.email = (auth.jwt() ->> 'email')));

create policy "Admins can delete events"
on public.events for delete to authenticated
using (exists (select 1 from public.admin_emails a where a.email = (auth.jwt() ->> 'email')));
```

### room_subscribers (event reminders)
```sql
create table if not exists public.room_subscribers (
  id uuid primary key default gen_random_uuid(),
  room text not null,
  email text not null,
  created_at timestamptz not null default now()
);
alter table public.room_subscribers enable row level security;

drop policy if exists "Anyone can subscribe" on public.room_subscribers;
create policy "Anyone can subscribe"
on public.room_subscribers for insert to anon, authenticated with check (true);

drop policy if exists "Admins can read subscribers" on public.room_subscribers;
create policy "Admins can read subscribers"
on public.room_subscribers for select to authenticated
using (exists (select 1 from public.admin_emails a where a.email = (auth.jwt() ->> 'email')));
```

### newsletter_subscribers
```sql
create table if not exists public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now()
);
alter table public.newsletter_subscribers enable row level security;

drop policy if exists "Anyone can join newsletter" on public.newsletter_subscribers;
create policy "Anyone can join newsletter"
on public.newsletter_subscribers for insert to anon, authenticated with check (true);
```

## Run locally
```
npm install
npm run dev
```

## Build and Deploy (Netlify)
- Build: `npm run build`
- Publish directory: `dist`
- Ensure `netlify.toml` contains SPA redirect and the scheduled function.
