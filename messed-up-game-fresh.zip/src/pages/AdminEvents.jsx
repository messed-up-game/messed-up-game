import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export default function AdminEvents(){
  const [list, setList] = useState([])
  const [form, setForm] = useState({ title:'', room:'messedup-live', is_public:true, starts_at:'', recurrence:'none', timezone:'America/Los_Angeles', weekday:5, time_of_day:'19:00' })

  async function load(){
    const { data } = await supabase.from('events').select('*').order('created_at', { ascending:false }).limit(200)
    setList(data || [])
  }
  useEffect(()=>{ load() }, [])

  async function create(){
    const payload = { ...form }
    if (payload.recurrence === 'none' && !payload.starts_at) { alert('Pick a date/time or set recurrence'); return }
    if (payload.recurrence !== 'none') payload.starts_at = null
    const { error } = await supabase.from('events').insert(payload)
    if (error) return alert(error.message)
    setForm({ title:'', room:'messedup-live', is_public:true, starts_at:'', recurrence:'none', timezone:'America/Los_Angeles', weekday:5, time_of_day:'19:00' })
    await load()
  }

  async function del(id){
    if (!confirm('Delete this event?')) return
    const { error } = await supabase.from('events').delete().eq('id', id)
    if (error) return alert(error.message)
    await load()
  }

  return (
    <div className="container">
      <div className="panel">
        <h1>Admin — Events</h1>
        <div className="row" style={{gap:8, flexWrap:'wrap'}}>
          <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
          <input placeholder="Room" value={form.room} onChange={e=>setForm({...form, room:e.target.value})} />
          <label><input type="checkbox" checked={form.is_public} onChange={e=>setForm({...form, is_public:e.target.checked})}/> Public</label>
          <select value={form.recurrence} onChange={e=>setForm({...form, recurrence:e.target.value})}>
            <option value="none">One-time</option>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
          </select>
          {form.recurrence==='none' && (<input type="datetime-local" value={form.starts_at} onChange={e=>setForm({...form, starts_at:e.target.value})} />)}
          {form.recurrence!=='none' && (
            <>
              <select value={form.timezone} onChange={e=>setForm({...form, timezone:e.target.value})}>
                <option>America/Los_Angeles</option>
                <option>America/New_York</option>
                <option>Europe/London</option>
              </select>
              {form.recurrence==='weekly' && (
                <select value={form.weekday} onChange={e=>setForm({...form, weekday:parseInt(e.target.value)})}>
                  <option value={0}>Sunday</option><option value={1}>Monday</option><option value={2}>Tuesday</option>
                  <option value={3}>Wednesday</option><option value={4}>Thursday</option><option value={5}>Friday</option><option value={6}>Saturday</option>
                </select>
              )}
              <input type="time" value={form.time_of_day} onChange={e=>setForm({...form, time_of_day:e.target.value})} />
            </>
          )}
          <button onClick={create}>Create</button>
        </div>
      </div>

      {list.map(e => (
        <div key={e.id} className="player" style={{display:'grid', gridTemplateColumns:'1fr auto', alignItems:'center'}}>
          <div>
            <div><strong>{e.title}</strong></div>
            <div className="small">{e.starts_at ? new Date(e.starts_at).toLocaleString() : `${e.recurrence.toUpperCase()} @ ${e.time_of_day} (${e.timezone})`}</div>
            <div className="small">Room: {e.room} • Public: {String(e.is_public)}</div>
          </div>
          <div className="row">
            <button onClick={()=> del(e.id)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  )
}
