import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const TWO_WEEKS_DAYS = 14;
function toZonedDate(date, timeZone) {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false
  });
  const parts = fmt.formatToParts(date).reduce((acc, p) => (acc[p.type] = p.value, acc), {});
  const [month, day, year] = [parts.month, parts.day, parts.year].map(n=>parseInt(n,10));
  const [hour, minute] = [parts.hour, parts.minute].map(n=>parseInt(n,10));
  return { year, month, day, hour, minute };
}
function fromZonedParts({year, month, day, hour=0, minute=0}, timeZone) {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  const guess = Date.UTC(year, month-1, day, hour, minute, 0);
  const corrected = new Date(guess);
  for (let i=0; i<3; i++) {
    const parts = dtf.formatToParts(corrected).reduce((acc, p) => (acc[p.type] = p.value, acc), {});
    const zoned = Date.UTC(parseInt(parts.year), parseInt(parts.month)-1, parseInt(parts.day),
                           parseInt(parts.hour), parseInt(parts.minute), parseInt(parts.second));
    const diff = zoned - corrected.getTime();
    if (diff === 0) break;
    corrected.setTime(corrected.getTime() - diff);
  }
  return corrected;
}
function expandRecurringRows(rows) {
  const out = [];
  const now = new Date();
  const tzDefault = 'America/Los_Angeles';
  const startParts = toZonedDate(now, tzDefault);
  let cursor = fromZonedParts({ year:startParts.year, month:startParts.month, day:startParts.day, hour:0, minute:0 }, tzDefault);
  for (const r of rows) {
    const tz = r.timezone || tzDefault;
    const [hh, mm] = (r.time_of_day || '10:00').split(':').map(x=>parseInt(x,10));
    for (let i=0; i<TWO_WEEKS_DAYS; i++) {
      const day = new Date(cursor.getTime() + i*86400000);
      const dayParts = toZonedDate(day, tz);
      const dow = day.getUTCDay();
      if (r.recurrence === 'daily' || (r.recurrence === 'weekly' && dow === (r.weekday ?? 0))) {
        const dt = fromZonedParts({ year:dayParts.year, month:dayParts.month, day:dayParts.day, hour:hh, minute:mm }, tz);
        out.push({ id: `${r.id || 'rec'}-${i}`, title:r.title, room:r.room, starts_at:dt.toISOString(), is_public:r.is_public });
      }
    }
  }
  return out;
}

export default function Events(){
  const nav = useNavigate()
  const [rows, setRows] = useState([])

  useEffect(()=>{
    async function load(){
      const { data, error } = await supabase
        .from('events')
        .select('id, title, starts_at, room, is_public, recurrence, timezone, weekday, time_of_day')
        .order('starts_at', { ascending: true })
        .limit(500)
      if (error) { console.error(error); return }
      const base = (data || []).filter(r => r.is_public)
      const oneTime = base.filter(r => r.starts_at)
      const recurring = base.filter(r => !r.starts_at && r.recurrence && r.recurrence !== 'none')
      const expanded = expandRecurringRows(recurring)
      const combined = [...oneTime, ...expanded]
        .filter(e => new Date(e.starts_at) >= new Date(Date.now() - 3600000))
        .sort((a,b)=> new Date(a.starts_at) - new Date(b.starts_at))
      setRows(combined)
    }
    load()
  }, [])

  async function subscribe(room){
    try {
      let { data: u } = await supabase.auth.getUser()
      let email = u?.user?.email
      if (!email) email = prompt('Enter your email for reminders:')
      if (!email) return
      const { error } = await supabase.from('room_subscribers').insert({ room, email })
      if (error) throw error
      alert('Subscribed — we will email ~30 min before start.')
    } catch(e){ alert(e.message || 'Failed to subscribe') }
  }

  return (
    <div className="container">
      <div className="panel">
        <h1>Events</h1>
        <p className="small">Pick a time, or click Notify me for reminders.</p>
      </div>
      {rows.map(e => (
        <div key={`${e.id}-${e.starts_at}`} className="player" style={{display:'grid', gridTemplateColumns:'1fr auto', alignItems:'center'}}>
          <div>
            <div><strong>{e.title}</strong></div>
            <div className="small">{new Date(e.starts_at).toLocaleString()} — Room: {e.room}</div>
          </div>
          <div className="row">
            <a className="button" href={`/room/${e.room}`}>Join</a>
            <button onClick={()=> subscribe(e.room)}>Notify me</button>
          </div>
        </div>
      ))}
      {rows.length===0 && (
        <div className="panel small">No upcoming events yet.</div>
      )}
    </div>
  )
}
