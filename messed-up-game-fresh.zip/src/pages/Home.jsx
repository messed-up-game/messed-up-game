import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const TWO_WEEKS_DAYS = 14;
function toZonedDate(date, timeZone) {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false
  });
  const parts = fmt.formatToParts(date).reduce((acc, p) => (acc[p.type] = p.value, acc), {});
  const [month, day, year] = [parts.month, parts.day, parts.year].map(n=>parseInt(n,10));
  const [hour, minute] = [parts.hour, parts.minute].map(n=>parseInt(n,10));
  return { year, month, day, hour, minute };
}
function fromZonedParts({year, month, day, hour=0, minute=0}, timeZone) {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  const guess = Date.UTC(year, month-1, day, hour, minute, 0);
  const corrected = new Date(guess);
  for (let i=0; i<3; i++) {
    const parts = dtf.formatToParts(corrected).reduce((acc, p) => (acc[p.type] = p.value, acc), {});
    const zoned = Date.UTC(parseInt(parts.year), parseInt(parts.month)-1, parseInt(parts.day),
                           parseInt(parts.hour), parseInt(parts.minute), parseInt(parts.second));
    const diff = zoned - corrected.getTime();
    if (diff === 0) break;
    corrected.setTime(corrected.getTime() - diff);
  }
  return corrected;
}
function expandRecurringRows(rows) {
  const out = [];
  const now = new Date();
  const tzDefault = 'America/Los_Angeles';
  const startParts = toZonedDate(now, tzDefault);
  let cursor = fromZonedParts({ year:startParts.year, month:startParts.month, day:startParts.day, hour:0, minute:0 }, tzDefault);
  for (const r of rows) {
    const tz = r.timezone || tzDefault;
    const [hh, mm] = (r.time_of_day || '10:00').split(':').map(x=>parseInt(x,10));
    for (let i=0; i<TWO_WEEKS_DAYS; i++) {
      const day = new Date(cursor.getTime() + i*86400000);
      const dayParts = toZonedDate(day, tz);
      const dow = day.getUTCDay();
      if (r.recurrence === 'daily' || (r.recurrence === 'weekly' && dow === (r.weekday ?? 0))) {
        const dt = fromZonedParts({ year:dayParts.year, month:dayParts.month, day:dayParts.day, hour:hh, minute:mm }, tz);
        out.push({ id: `${r.id || 'rec'}-${i}`, title:r.title, room:r.room, starts_at:dt.toISOString(), is_public:r.is_public });
      }
    }
  }
  return out;
}

export default function Home(){
  const nav = useNavigate()
  const [nextShow, setNextShow] = useState(null)

  useEffect(()=>{
    async function loadNext(){
      try{
        const { data, error } = await supabase
          .from('events')
          .select('id, title, starts_at, room, is_public, recurrence, timezone, weekday, time_of_day')
          .order('starts_at', { ascending: true })
          .limit(200)
        if (error) throw error
        const rows = (data || []).filter(r => r.is_public)
        const oneTime = rows.filter(r => r.starts_at)
        const recurring = rows.filter(r => !r.starts_at && r.recurrence && r.recurrence !== 'none')
        const expanded = expandRecurringRows(recurring)
        const combined = [...oneTime, ...expanded]
          .filter(e => new Date(e.starts_at) >= new Date(Date.now() - 3600000))
          .sort((a,b)=> new Date(a.starts_at) - new Date(b.starts_at))
        setNextShow(combined[0] || null)
      } catch{}
    }
    loadNext()
  }, [])

  async function subscribeNewsletter(e){
    e.preventDefault()
    const email = e.target.email.value
    if (!email) return
    try {
      const { error } = await supabase.from('newsletter_subscribers').insert({ email })
      if (error) throw error
      alert('Subscribed! You will get updates by email.')
      e.target.reset()
    } catch(err){
      alert(err.message || 'Could not subscribe')
    }
  }

  return (
    <div className="container">
      <div className="panel" style={{background:'#0b0f26', padding:'28px', borderRadius:'16px', border:'1px solid #262b5a'}}>
        <h1 style={{marginTop:0}}>Messed Up Game — Play it Live Online</h1>
        <p className="small" style={{maxWidth:720}}>
          A chaotic, hilarious party game you can play from anywhere. Join a live room, fling virtual pizzas,
          and try not to get <em>messed up</em>. Stream-ready, browser-only, no installs required.
        </p>
        <div className="row" style={{gap:10, flexWrap:'wrap'}}>
          <button onClick={()=> nav('/events')}>See Events</button>
          <a href={import.meta.env.VITE_STRIPE_PAYMENT_LINK_TICKET} className="button">Buy Ticket</a>
          <a href={import.meta.env.VITE_STRIPE_PAYMENT_LINK_TIP} className="button">Tip the Host</a>
        </div>
      </div>

      <div className="panel">
        <h2>Next Live Show</h2>
        {!nextShow && <p className="small">No show scheduled yet. Check the <a href="/events">Events</a> page.</p>}
        {nextShow and (
          <div className="player" style={{display:'grid', gridTemplateColumns:'1fr auto', alignItems:'center'}}>
            <div>
              <div><strong>{nextShow.title}</strong></div>
              <div className="small">{new Date(nextShow.starts_at).toLocaleString()} — Room: {nextShow.room}</div>
            </div>
            <div style={{display:'flex', gap:6}}>
              <a className="button" href={'/room/' + nextShow.room}>Join</a>
              <a className="button" href="/events">More times</a>
            </div>
          </div>
        )}
      </div>

      <div className="panel">
        <h2>How to Play</h2>
        <ol className="small" style={{lineHeight:1.8}}>
          <li>Pick a time on <strong>Events</strong>.</li>
          <li>Allow mic/camera when prompted. Enter a display name.</li>
          <li>If the lobby is locked, click <strong>Knock to Join</strong> and the host will admit you.</li>
          <li>Use on-screen controls to fling items and react. Three strikes and you’re out!</li>
          <li>For reminders, on <strong>Events</strong> click <strong>Notify me</strong> on a time that works.</li>
        </ol>
        <p className="small" style={{color:'#9aa0d0'}}>Powered by Got Backup Tom B.</p>
      </div>

      <div className="panel">
        <h2>Join the Newsletter</h2>
        <p className="small">Get updates about new shows, promotions, and special events.</p>
        <form onSubmit={subscribeNewsletter}>
          <input type="email" name="email" placeholder="Your email" required
            style={{padding:'8px', borderRadius:'6px', border:'1px solid #444'}}/>
          <button type="submit" style={{marginLeft:'8px'}}>Subscribe</button>
        </form>
      </div>
    </div>
  )
}
