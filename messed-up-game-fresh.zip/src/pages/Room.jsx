import React, { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export default function Room(){
  const { roomId } = useParams()
  const [isHost, setIsHost] = useState(false)
  const [admitted, setAdmitted] = useState(false)
  const [pending, setPending] = useState([])
  const [lobbyLocked, setLobbyLocked] = useState(true)
  const channelRef = useRef(null)
  const userKeyRef = useRef('user-' + Math.random().toString(36).slice(2))
  const [displayName, setDisplayName] = useState('Player')

  useEffect(()=>{
    const ch = supabase.channel(`room-${roomId}`, { config: { broadcast: { ack: true }}})
    channelRef.current = ch

    ch.on('broadcast', { event: 'knock' }, payload => {
      if (!isHost) return
      const k = payload.payload
      setPending(prev => prev.find(p=>p.key===k.key) ? prev : [...prev, k])
    })
    ch.on('broadcast', { event: 'admit' }, payload => {
      const { key } = payload.payload
      if (key === userKeyRef.current) setAdmitted(true)
      setPending(prev => prev.filter(p => p.key !== key))
    })
    ch.subscribe()
    return () => { ch.unsubscribe() }
  }, [roomId, isHost])

  function knock(){
    channelRef.current?.send({ type:'broadcast', event:'knock', payload:{ key: userKeyRef.current, name: displayName }})
  }
  function admit(key){
    channelRef.current?.send({ type:'broadcast', event:'admit', payload:{ key } })
  }

  return (
    <div className="container">
      <div className="panel">
        <h1>Room: {roomId}</h1>
        <div className="row" style={{gap:8}}>
          <label><input type="checkbox" checked={isHost} onChange={e=>setIsHost(e.target.checked)} /> I am the host</label>
          {isHost && <label><input type="checkbox" checked={lobbyLocked} onChange={e=>setLobbyLocked(e.target.checked)} /> Lobby locked</label>}
          {!isHost && lobbyLocked && !admitted && <button onClick={knock}>Knock to Join</button>}
          {!isHost && admitted && <span className="small">Admitted ✅</span>}
        </div>
      </div>

      {isHost && (
        <div className="panel">
          <h2>Lobby</h2>
          <div className="small">Pending knocks:</div>
          <ul style={{listStyle:'none', padding:0}}>
            {pending.map(k => (
              <li key={k.key} className="player" style={{display:'flex', justifyContent:'space-between'}}>
                <span>{k.name || k.key}</span>
                <button onClick={()=> admit(k.key)}>Admit</button>
              </li>
            ))}
            {pending.length===0 && <li className="small">No one is knocking.</li>}
          </ul>
        </div>
      )}

      <div className="panel">
        <h2>Game Area</h2>
        <p className="small">Placeholder for video/board. Once admitted, players can join your call / game view.</p>
      </div>
    </div>
  )
}
