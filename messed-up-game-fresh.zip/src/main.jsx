import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Events from './pages/Events'
import AdminEvents from './pages/AdminEvents'
import Room from './pages/Room'
import './styles.css'

function App(){
  return (
    <BrowserRouter>
      <div className="nav">
        <a href="/" className="brand">Messed Up Game</a>
        <div className="spacer"/>
        <a href="/events">Events</a>
        <a href="/admin-events">Admin</a>
      </div>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/events" element={<Events/>} />
        <Route path="/admin-events" element={<AdminEvents/>} />
        <Route path="/room/:roomId" element={<Room/>} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App/>)
