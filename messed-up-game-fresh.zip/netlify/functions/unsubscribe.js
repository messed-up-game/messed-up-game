exports.handler = async (event) => {
  try {
    const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
    const SERVICE_KEY  = process.env.SUPABASE_SERVICE_ROLE;
    if (!SUPABASE_URL || !SERVICE_KEY) return { statusCode:500, body:'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE' };
    const email=(event.queryStringParameters?.email||'').trim().toLowerCase();
    const room =(event.queryStringParameters?.room ||'').trim();
    if (!email || !room) return { statusCode:400, body:'Missing email or room' };
    const headers={ apikey:SERVICE_KEY, Authorization:`Bearer ${SERVICE_KEY}`, 'Content-Type':'application/json' };
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/room_subscribers?email=eq.${encodeURIComponent(email)}&room=eq.${encodeURIComponent(room)}`, { method:'DELETE', headers });
    if (!resp.ok) return { statusCode: resp.status, body: await resp.text() };
    return { statusCode:200, headers:{'Content-Type':'text/html'}, body:`<html><body style="font-family:Arial;padding:24px">You have been unsubscribed from reminders for room <b>${room}</b>.<br/><a href="/">Return to site</a></body></html>` };
  } catch(e){ return { statusCode:500, body:e.message }; }
};
