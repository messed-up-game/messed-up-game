const fs = require('fs'); const path = require('path');
const RESEND_API='https://api.resend.com/emails';

function renderTemplate(vars){
  const tpl = fs.readFileSync(path.join(__dirname, 'reminder-template.html'),'utf-8');
  return tpl.replace(/{{(\w+)}}/g, (_, key) => (vars[key] ?? ''));
}

exports.handler = async () => {
  const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const SERVICE_KEY   = process.env.SUPABASE_SERVICE_ROLE;
  const RESEND_API_KEY= process.env.RESEND_API_KEY;
  const FROM_EMAIL    = process.env.FROM_EMAIL || 'no-reply@messedup.local';
  const SITE_URL      = process.env.SITE_URL || '';

  if (!SUPABASE_URL || !SERVICE_KEY) {
    return { statusCode: 500, body: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE' };
  }

  const headers = { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, 'Content-Type':'application/json' };
  const events = await (await fetch(`${SUPABASE_URL}/rest/v1/events?select=*`, { headers })).json();
  const subs   = await (await fetch(`${SUPABASE_URL}/rest/v1/room_subscribers?select=*`, { headers })).json();

  const now = new Date(); const in30 = new Date(now.getTime() + 30*60000);

  function* expandRecurring(e){
    const tz = e.timezone || 'America/Los_Angeles';
    const fmt = (d) => new Intl.DateTimeFormat('en-US', { timeZone: tz, hour12:false, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' })
      .formatToParts(d).reduce((a,p)=>(a[p.type]=p.value,a),{});
    function fromZoned(y,m,d,hh,mm){
      const dtf=new Intl.DateTimeFormat('en-US',{ timeZone:tz, hour12:false, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit' });
      const guess=Date.UTC(y,m-1,d,hh,mm,0); const corrected=new Date(guess);
      for (let i=0;i<3;i++){ const p=dtf.formatToParts(corrected).reduce((a,q)=>(a[q.type]=q.value,a),{});
        const zoned=Date.UTC(+p.year,+p.month-1,+p.day,+p.hour,+p.minute,+p.second);
        const diff=zoned-corrected.getTime(); if(diff===0) break; corrected.setTime(corrected.getTime()-diff) }
      return corrected;
    }
    const parts=fmt(now); const base=fromZoned(+parts.year,+parts.month,+parts.day,0,0);
    const [hh,mm]=(e.time_of_day||'10:00').split(':').map(n=>parseInt(n,10));
    for(let i=0;i<2;i++){ const day=new Date(base.getTime()+i*86400000); const dow=day.getUTCDay();
      if(e.recurrence==='daily'||(e.recurrence==='weekly'&&dow===(e.weekday??0))){
        const p=new Intl.DateTimeFormat('en-US',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(day).reduce((a,t)=>(a[t.type]=t.value,a),{});
        yield fromZoned(+p.year,+p.month,+p.day,hh,mm);
      } }
  }

  const upcoming=[];
  for(const e of events){
    if (e.is_public !== true) continue;
    if (e.starts_at){
      const s = new Date(e.starts_at);
      if (s>=now && s<=in30) upcoming.push({ title:e.title, room:e.room, starts_at:s, timezone:e.timezone });
    } else if (e.recurrence && e.recurrence!=='none'){
      for (const s of expandRecurring(e)){
        if (s>=now && s<=in30) upcoming.push({ title:e.title, room:e.room, starts_at:s, timezone:e.timezone });
      }
    }
  }

  const byRoom = subs.reduce((m, r) => ((m[r.room] ??= []).push(r.email), m), {});

  let sent = 0;
  for (const ev of upcoming){
    const list = byRoom[ev.room] || [];
    if (list.length===0) continue;
    const tz = ev.timezone || 'America/Los_Angeles';
    const starts_local = new Intl.DateTimeFormat('en-US', { timeZone: tz, dateStyle:'medium', timeStyle:'short' }).format(ev.starts_at);
    const subject = `Starting soon: ${ev.title}`;
    for (const email of list){
      const html = renderTemplate({ subject, site_url: SITE_URL, title:ev.title, room:ev.room, starts_local, email });
      if (!RESEND_API_KEY){ console.log('Would email', email, subject); continue; }
      const res = await fetch(RESEND_API, { method:'POST', headers:{ Authorization:`Bearer ${RESEND_API_KEY}`, 'Content-Type':'application/json' }, body: JSON.stringify({ from: FROM_EMAIL, to: email, subject, html }) })
      if (res.ok) sent++;
    }
  }
  return { statusCode: 200, body: JSON.stringify({ upcoming: upcoming.length, sent }) };
}
